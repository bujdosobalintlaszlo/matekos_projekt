function Feltoltes()
{
  document.body.innerHTML +="";
  document.body.innerHTML =`<nav class="navbar">
  <div class="container-fluid">
    <span class="navbar-brand mb-0 h1"><button type="button" class="btn btn-light" onclick="VisszaMenu()">Vissza</button></span>
  </div>
</nav>
<div id="tartalom">
  <div class="row row-cols-2">
    <div class="col-12 col-xl-6">
      <form id="hozaadasForm">
        <div class="mb-3">
          <label for="hozaadasForm" class="form-label"><h3><b>Feladat neve:</b></h3></label>
          <textarea class="form-control" id="feladatNevForm" rows="1" maxlength="50" onkeyup="BeirCim()"></textarea>
        </div>
        <div class="mb-1">
          <label for="hozaadasForm" class="form-label"><h3><b>Feladat szövege:</b></h3></label>
          <textarea class="form-control" id="feladatForm" rows="3" maxlength="250" onkeyup="BeirFeladat()"></textarea>
        </div>
        <div class="mb-2">
          <label for="hozaadasForm" class="form-label"><h3><b>Megoldás:</b></h3></label>
          <textarea class="form-control" id="megoldasForm" rows="1" maxlength="250" onkeyup="BeirMegoldas()"></textarea>
        </div>
        <div class="mb-3">
          <label for="hozaadasForm" class="form-label"><h3><b>Nehézségi szint:</b></h3></label>
          <textarea class="form-control" id="szintForm" rows="1" maxlength="250" onkeyup="BeirNehezeseg()"></textarea>
        </div>
        <div class="mb-3">
          <label for="hozaadasForm" class="form-label"><h3><b>Pontszám:</b></h3></label>
          <textarea class="form-control" id="pontszamForm" rows="1" maxlength="250" onkeyup="BeirPontszam()"></textarea>
        </div>
      </form>
      <input type="button" value="Jóváhagy">
    </div>
    <div class="col-12 col-xl-6" id="megjelenit"><h3><b>Megjelenés:</b></h3>
    <h3 id="FeladatNev"></h3>
    <p id="szint"></p><br>
    <p id="feladat"></p>
    <p>Válasz:</p><input type="text" id="megoldas" disabled class="col-12">
    <p id="pontszam"></p>
  </div>
</div>
</div>`;
}

function BeirCim()
{
    var nev = document.getElementById("feladatNevForm").value;
    console.log(nev);
    document.getElementById("FeladatNev").innerHTML = `${nev}`;
}

function BeirFeladat() {
    var feladatInput = document.getElementById("feladatForm").value;
    var arr = feladatInput.split("|");
    console.log(arr);
    var mathjaxFormattedFeladat = "\\( " + arr[1] + " \\)";
    var feladatText = "A feladat: " + arr[0];

    document.getElementById("feladat").innerHTML = feladatText + "<br>" + mathjaxFormattedFeladat;
    MathJax.typeset();
}

function BeirMegoldas()
{
    var nev = document.getElementById("megoldasForm").value;
    console.log(nev);
    document.getElementById("megoldas").placeholder = `${nev}`;
}

function BeirNehezeseg()
{
    var nev = document.getElementById("szintForm").value;
    console.log(nev);
    document.getElementById("szint").innerHTML = `${nev}`;
}

function BeirPontszam()
{
    var nev = document.getElementById("pontszamForm").value;
    console.log(nev);
    document.getElementById("pontszam").innerHTML = `${nev}`;
}

function VisszaMenu()
{
  location.reload();
}