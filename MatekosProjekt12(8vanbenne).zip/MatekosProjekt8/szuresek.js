function KozepSzur()
{
    var hely = document.getElementById("jobb");
    hely.innerHTML=' ';
    feladatok.forEach(adattag => {
        if(adattag.nehezseg == "0")
        {
        let div = document.createElement("div");
        div.id = adattag.id;
        div.classList.add("feladat");
        div.classList.add("col-12");
        div.classList.add("row");

        let szinResult = Szinez(adattag.nehezseg);
        div.innerHTML = `
            <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}">
                <p>${adattag.id}.</p>
            </div>
            <div class="feladatNev col-5">
                <p>${adattag.nev}</p>
            </div>
            <div class="feladatTemakor col-5">
                <p id="${adattag.id}temakorP"></p>
            </div>
        `;
        TemakorBeiir(adattag.temakorId,`${adattag.id}temakorP`);
        hely.appendChild(div);
        hely.appendChild(document.createElement("br"));
        }
    });
    console.log(feladatok);
}

function EmeltSzur()
{
    var hely = document.getElementById("jobb");
    hely.innerHTML=' ';
    feladatok.forEach(adattag => {
        if(adattag.nehezseg == "1")
        {
        let div = document.createElement("div");
        div.id = adattag.id;
        div.classList.add("feladat");
        div.classList.add("col-12");
        div.classList.add("row");

        let szinResult = Szinez(adattag.nehezseg);
        div.innerHTML = `
            <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}">
                <p>${adattag.id}.</p>
            </div>
            <div class="feladatNev col-5">
                <p>${adattag.nev}</p>
            </div>
            <div class="feladatTemakor col-5">
                <p id="${adattag.id}temakorP"></p>
            </div>
        `;
        TemakorBeiir(adattag.temakorId,`${adattag.id}temakorP`);
        hely.appendChild(div);
        hely.appendChild(document.createElement("br"));
        }
    });
}


function VersenySzur()
{
    var hely = document.getElementById("jobb");
    hely.innerHTML=' ';
    feladatok.forEach(adattag => {
        if(adattag.nehezseg == "2")
        {
        let div = document.createElement("div");
        div.id = adattag.id;
        div.classList.add("feladat");
        div.classList.add("col-12");
        div.classList.add("row");

        let szinResult = Szinez(adattag.nehezseg);
        div.innerHTML = `
            <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}">
                <p>${adattag.id}.</p>
            </div>
            <div class="feladatNev col-5">
                <p>${adattag.nev}</p>
            </div>
            <div class="feladatTemakor col-5">
                <p id="${adattag.id}temakorP"></p>
            </div>
        `;
        TemakorBeiir(adattag.temakorId,`${adattag.id}temakorP`);
        hely.appendChild(div);
        hely.appendChild(document.createElement("br"));
        }
    });
}

function JelSzur()
{
    var hely = document.getElementById("jobb");
    hely.innerHTML=' ';
    feladatok.forEach(adattag => {
        if(parseInt(adattag.nehezseg) >= 3)
        {
        let div = document.createElement("div");
        div.id = adattag.id;
        div.classList.add("feladat");
        div.classList.add("col-12");
        div.classList.add("row");

        let szinResult = Szinez(adattag.nehezseg);
        div.innerHTML = `
            <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}">
                <p>${adattag.id}.</p>
            </div>
            <div class="feladatNev col-5">
                <p>${adattag.nev}</p>
            </div>
            <div class="feladatTemakor col-5">
                <p id="${adattag.id}temakorP"></p>
            </div>
        `;
        TemakorBeiir(adattag.temakorId,`${adattag.id}temakorP`);
        hely.appendChild(div);
        hely.appendChild(document.createElement("br"));
        }
    });
}

function Osszes()
{
    document.getElementById("jobb").innerHTML ="";
    FeladatokFeltolt("jobb");
}
/*
function TemakorSzures()
{
    var hely = document.getElementById("jobb");
    var ok = checkedKategoriak();
    console.log(ok);
    hely.innerHTML ='';
    feladatok.forEach(adattag => {
        if(ok.includes(adattag))
        {
        let div = document.createElement("div");
        div.id = adattag.id;
        div.classList.add("feladat");
        div.classList.add("col-12");
        div.classList.add("row");

        let szinResult = Szinez(adattag.nehezseg);
        div.innerHTML = `
            <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}">
                <p>${adattag.id}.</p>
            </div>
            <div class="feladatNev col-5">
                <p>${adattag.nev}</p>
            </div>
            <div class="feladatTemakor col-5">
                <p id="${adattag.id}temakorP"></p>
            </div>
        `;
        TemakorBeiir(adattag.temakorId,`${adattag.id}temakorP`);
        hely.appendChild(div);
        hely.appendChild(document.createElement("br"));
        }
    });
}

let temakorSzam = () => {
    let sql = "SELECT COUNT(*) as db FROM temakor";
    return LekerdezesEredmenye(sql).then((valasz) => {
        console.log(valasz[0].db);
        return valasz[0].db;
    });
};

let checkedKategoriak = () => {
    let length = temakorSzam();
    let checkedElem = [];
    for (let i = 0; i < length; ++i) {
        let curr = document.getElementById(`${i}temakor`);
        if (curr.checked) {
            checkedElem.push(curr.value);
        }
    }
    console.log(checkedElem);
    return checkedElem;
};

*/
var van = false;
function TemakorSzures(id){
    var hely = document.getElementById("jobb");
    if(van ==false)
    {   
    hely.innerHTML=' ';
    }
    console.log(id);    
    feladatok.forEach(adattag => {
        if(adattag.temakorId == id)
        {
        let div = document.createElement("div");
        div.id = adattag.id;
        div.classList.add("feladat");
        div.classList.add("col-12");
        div.classList.add("row");

        let szinResult = Szinez(adattag.nehezseg);
        div.innerHTML += `
            <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}">
                <p>${adattag.id}.</p>
            </div>
            <div class="feladatNev col-5">
                <p>${adattag.nev}</p>
            </div>
            <div class="feladatTemakor col-5">
                <p id="${adattag.id}temakorP"></p>
            </div>
        `;
        TemakorBeiir(adattag.temakorId,`${adattag.id}temakorP`);
        hely.appendChild(div);
        hely.appendChild(document.createElement("br"));
        van = true;
        }
    });
}
