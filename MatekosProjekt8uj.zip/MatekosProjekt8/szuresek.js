//Szintszureshez valotozok
var OsszesSzur = false;
var kozepSzur = false;
var emeltSzur = false;
var versenySzur = false;
var jelSzur = false;
//------------------
var kat = false;

//ebbe gyujtjuk a kiszurt feladatokat es jelenitjuk meg(ez egy tomb)
var szurt =[];
var eredetiSzurt=[];
//--------------

function szur() {
    console.log(eredetiSzurt,szurt);
    szurt =[];
    if (kozepSzur) {
        szurt = szurt.concat(eredetiSzurt.filter(x => x.nehezseg == "0"));
    } 
    if (emeltSzur) {
        szurt = szurt.concat(eredetiSzurt.filter(x => x.nehezseg == "1"));
    } 
    if (versenySzur) {
        szurt = szurt.concat(eredetiSzurt.filter(x => x.nehezseg == "2"));
    } 
    if (jelSzur) {
        szurt = szurt.concat(eredetiSzurt.filter(x => parseInt(x.nehezseg) >= 3));
    } 
    if (!(jelSzur || kozepSzur || emeltSzur || versenySzur)) {
        szurt=eredetiSzurt;
    }
    MegjelenitItems();
}

function KozepSzur() {
    kozepSzur=!kozepSzur;
    szur();
}

function EmeltSzur() {
    emeltSzur=!emeltSzur;
    szur();
}


function VersenySzur() {
    versenySzur=!versenySzur;
    szur();
}

function JelSzur() {
    jelSzur=!jelSzur;
    szur();
}

function Osszes() {
    document.getElementById("jobb").innerHTML = "";
    FeladatokFeltolt("jobb");
    OsszesSzur = false;
    kozepSzur = false;
    emeltSzur = false;
    versenySzur = false;
    jelSzur = false;
}

function TemakorSzures(id) {
    if (document.getElementById(id).checked) {
        szurt = szurt.concat(feladatok.filter(x => x.temakorId == id));
        MegjelenitItems();
    } else {
        szurt = szurt.filter(x => x.temakorId != id);
        MegjelenitItems();
    }

    if(szurt.length === 0){
        Osszes();
    }
    eredetiSzurt=szurt;
}

 function MegjelenitItems(){
        var hely = document.getElementById("jobb");
        hely.innerHTML="";  
        szurt.forEach(adattag=>{
        let div = document.createElement("div");
        div.id = adattag.id;
        div.classList.add("feladat");
        div.classList.add("col-12");
        div.classList.add("row");
        let szinResult = Szinez(adattag.nehezseg);
        div.innerHTML = `
        <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}">
            <p>${adattag.id}.</p>
        </div>
        <div class="feladatNev col-5">
            <p>${adattag.nev}</p>
        </div>
        <div class="feladatTemakor col-5">
            <p id="${adattag.id}temakorP"></p>
        </div>`;
        TemakorBeiir(adattag.temakorId, `${adattag.id}temakorP`);
        hely.appendChild(div);
        hely.appendChild(document.createElement("br"));
    });
 }