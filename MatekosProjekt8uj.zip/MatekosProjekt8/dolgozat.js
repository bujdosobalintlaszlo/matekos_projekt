var jelenlegi;
var dolgozatIdTomb = [];
function DolgozatokGen(){
    document.body.innerHTML="";
    document.body.innerHTML = `
    <nav class="navbar navbar-expand-lg" id="nav">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <span>
                <li class="nav-item">
                    <input type="button" value="Vissza" class="btn btn-light terKoz" onclick="Vissza()">
                </li>
            </span>
        <span>
            <li class="nav-item">
                <input type="button" value="Hozzáad" class="btn btn-light terKoz" onclick="Hozzaad()">
            </li>
        </span>
        <span>
            <li class="nav-item">
                <input type="button" value="Kivesz" class="btn btn-light terKoz" onclick="Kivesz()">
            </li>
        </span>
    </div>
    </div>
</nav>
    <div class="row">
      <div class="col" id="kereses">
        <form class="d-flex col-md-6 col-s-12" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
          </form><br>
      </div>
      <div class="col-md-6 col-s-12" id="feladatok">
      <h1 id="cim">
      A feladatok:
        </h1>
      </div>
    </div>
</div>`;
FeladatokFeltoltDolgozat("kereses");
}

function FeladatokFeltoltDolgozat(divId) {
    var hely = document.getElementById(divId);
    feladatok.forEach(adattag => {
        let div = document.createElement("div");
        div.id = adattag.id;
        div.classList.add("feladat");
        div.classList.add("col-12");
        div.addEventListener('click', function() {
            Megtart(adattag.id);
        });        
        let szinResult = Szinez(adattag.nehezseg);
        div.innerHTML = `
            <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}">
                <p>${adattag.id}.</p>
            </div>
            <div class="feladatNev col-5">
                <p>${adattag.nev}</p>
            </div>
            <div class="feladatTemakor col-5">
                <p id="temakorP"></p>
            </div>
        `;
        TemakorBeiir(adattag.temakor);
        hely.appendChild(div);
        hely.appendChild(document.createElement("br"));
    });
  }
function Megtart(id) {
jelenlegi=id;
console.log(id);
}
function Hozzaad()
{
    dolgozatIdTomb.push(jelenlegi);
    Megjelenit();
}
var megjelenitLista = [];
function Megjelenit()
{
    var j =0;
    for(let i=0;i<dolgozatIdTomb.length;++i){
        console.log("index:" +" "+ j);
        while(dolgozatIdTomb[i] != feladatok[j].id){
            j++;
        }
        megjelenitLista.push(j);
    }
    FeladatKartyaGen("cim");
}
function FeladatKartyaGen(divId)
{
    console.log(feladatok[jelenlegi-1].nehezseg);
    var hely = document.getElementById(divId);
    var div = document.createElement("div");
    let szinResult = Szinez(feladatok[jelenlegi-1].nehezseg);
    div.innerHTML = `
        <div class="sorszam" id="${feladatok[jelenlegi-1].id}" style="background-color: ${szinResult.color}">
            <p class=" col-1">${feladatok[jelenlegi-1].id}.</p>
        </div>
        <div class="col-11 col-sm-7">
            <p class="feladatNevP">${feladatok[jelenlegi-1].nev}</p>
        </div>
        <div class="col-sm-4  d-none d-sm-block ">
            ${SzambolTemakor()}
        </div>`;
    hely.appendChild(div);
    hely.appendChild(document.createElement("br"));
}
function SzambolTemakor (){
    let sql = `select t.temakor as tema from temakor t where t.id = ${feladatok[jelenlegi].temakorId}`;
    LekerdezesEredmenye(sql).then((valasz)=>{
        let p = document.createElement("p");
        p.classList.add("temakorP");
        p.innerHTML=valasz[0].tema;
       //return valasz[0].tema;
    });
}
function VisszaMenu()
{
  location.reload();
}

function TemakorBeiir(){

}