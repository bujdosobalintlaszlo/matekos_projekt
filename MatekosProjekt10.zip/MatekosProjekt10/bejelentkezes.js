

const AdatbazisEleres = () => {
    fetch("http://127.0.0.1:3000")
        .then(function (response) {
            if (!response.ok) {
                alert("Nem jó válasz érekezett az adatbázisból");
                return Promise.reject("Nem jó válasz érekezett az adatbázisból");
            }
            return response.json();
        })
        .then(function (response) {
            if (response.Error) {
                alert(response.Error);
                console.log(response.Error);
            } else {
                alert("Az adatbázis kapcsolat él, az adatokat eléri.");
                console.log("Táblák");
                response.forEach(element => {
                    console.log(element);
                });
            }
        });
}
AdatbazisEleres();
const LekerdezesEredmenye = (sql) => {
    const data = { lekerdezes: sql };
    return fetch("http://127.0.0.1:3000/lekerdezes", {
        method: "POST",
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
        },
        body: JSON.stringify(data)
    })
        .then(function (response) {
            if (!response.ok) {
                return Promise.reject("Nem jó válasz érekezett az adatbázisból");
            }
            return response.json();
        })
        .then(function (response) {
            if (response.Error) {
                return response.Error;
            } else {
                return response;
            }
        });
}
async function hash(string) {
    const utf8 = new TextEncoder().encode(string);
    return crypto.subtle.digest('SHA-256', utf8).then((hashBuffer) => {
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray
            .map((bytes) => bytes.toString(16).padStart(2, '0'))
            .join('');
        return hashHex;
    });
}
function Login() {
    let regE = document.getElementById("regem");
    let pw = document.getElementById("fnjelsz");
    const regExpEmail=/[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$/;
    const regExpPw=/[A-Za-z0-9\.\_]{8,16}$/;
    if(regExpEmail.test(regE.value) && regExpPw.test(pw.value))
    {
    hash(pw).then((valasz)=>{
        let sql2 = `select f.felhasznaloNev from felhasznalok f where f.email = '${regE.value}' && f.jelszo = '${valasz}'`;
        console.log(sql2);
        LekerdezesEredmenye(sql2).then((valasz2) => {
            console.log(valasz);
            if(valasz2)
            {
              console.log(valasz2);
                var nev = ""+valasz2[0].felhasznaloNev;
                console.log(nev);
                let sql = `select f.jog from felhasznalok f where f.email = '${regE.value}'`;
                console.log(sql);
                sessionStorage.setItem("email",regE.value);
                sessionStorage.setItem("fn",valasz2[0].felhasznaloNev);
                sessionStorage.setItem("login",true);
                LekerdezesEredmenye(sql).then((valasz3) => {
                  if(valasz2[0].jog == "1"){
                    nev +="(admin)";
                    console.log(nev);
                    sessionStorage.setItem("jog",valasz3[0].jog);
                    FooldalgenReg(nev,regE.value);

                }else{
                    sessionStorage.setItem("jog",valasz3[0].jog);
                    FooldalgenReg(nev,regE.value);
                }
            });
            }
            else
            {
                alert("hiba");
            }
        });
    });
  }else{
    if(!regExpEmail.test(regE)){
        regE.style.border = "1px solid red";
    }if(!regExpPw.test(pw.value)){
      pw.style.border = "1px solid red";
    }if(!regExpEmail.test(regE) && !regExpPw.test(pw.value)){
      regE.style.border = "1px solid red";
      pw.style.border = "1px solid red";
    }
  }
}


async function Regisztracio(){
    //Bejelentkezési információk lekérése
    let felhasznalo = document.getElementById("regFf");
    let email = document.getElementById("regem");
    let jelszo1 = document.getElementById("fnjelsz");
    let jelszo2 = document.getElementById("fnjelszujra");
    let osztaly = document.getElementById("osztaly");
    var gomb=document.getElementById("bejelentkezes");
    //-----

    //Alaphelyzetbe állítás
    felhasznalo.style.border="none";
    email.style.border="none";
    osztaly.style.border ="none";
    jelszo1.style.border="none";
    jelszo2.style.border="none";
    //-----------------------

    //Kikapcsoljuk a bejelentkezes gombot
    gomb.disabled=true;

    //billegtetett változó ez alapján dől el, hogy tovább fut az ellenőrzés vagy hibát jelez
    let joe=true;
    
    //felhasználónév ellenőrzése
    const regExpFn=/[A-Za-z0-9]{5,16}$/;
    if (!regExpFn.test(felhasznalo.value)){
        joe=false;
        gomb.disabled=true;
        console.log("hiba - fn");
        felhasznalo.style.border="1px solid red";
    } else {
        sql="select count(*) as darab from felhasznalok where felhasznaloNev='"+felhasznalo.value+"'";
        console.log(sql);
        LekerdezesEredmenye(sql).then((valasz)=>{
            if (valasz[0].darab !=undefined && valasz[0].darab!=0) {
                gomb.disabled=true;
                joe=false;
                felhasznalo.style.border="1px solid red"; 
                alert("A felhasználónév már létezik! Válassz mást vagy szólj a rendszergazdának")
            } 
        });
    }
    //----------------------
    //Email ellenőrzése
    const regExpEmail=/[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$/;
    if (!regExpEmail.test(email.value)) {
        joe=false;
        gomb.disabled=true;
        email.style.border="1px solid red";
    } else {
        sql="select count(*) as darab from felhasznalok where email='"+email.value+"'";
        LekerdezesEredmenye(sql).then((valasz)=>{
          console.log(valasz[0].darab + "anyad");
            if (valasz[0].darab !="0") {
                joe=false;
                email.style.border="1px solid red";
                alert("Az emailcím már használatban van! Fordulj a rendszergazdához ha problémád van ezzel!");
            } 
        });
    }
    //-------------------
    //osztály ellenőrzése
    const osztalyRegExp = /^(9|10|11|12|13)([A-C]|K)$/;
    if(!osztalyRegExp.test(osztaly.value) && osztaly.value != "non"){
        joe=false;
        gomb.disabled=true;
        osztaly.style.border ="1px solid red";
    }
    //------------------
    //Jelszo ellenőrzése
    if(jelszo1.value != jelszo2.value){
        joe = false;
        gomb.disabled=true;
        jelszo1.style.border="1px solid red";
        jelszo2.style.border="1px solid red";
        
    }else{

        if(!ErosE(jelszo1.value,felhasznalo.value))
        {
            //info.innerHTML=`A jelszó nem megfelelő!! `;
            joe = false;
            gomb.disabled=false;
            jelszo1.style.border="1px solid red";
            jelszo2.style.border="1px solid red";
            alert("A jelszavad gyenge!(Tartalmazzon: kis- és nagybetűt, legalább 1 _ vagy . -ot! :))")
        }
    }
    //------------
    //Ha minden jó adatbázisbaküldés,sessionstorageba mentés
    if(joe)
    {
        hash(jelszo1.value).then((hash)=> {
            let sql = "INSERT INTO felhasznalok VALUES (null, '" + email.value + "', '" + hash + "','"+felhasznalo.value+"', 0, '" + osztaly.value+ "');";
            console.log(sql);
            LekerdezesEredmenye(sql).then((valasz)=>{
                console.log(valasz);
                console.log("jo");
            });
            let sql2 = `SELECT * FROM felhasznalok f WHERE f.felhasznaloNev = '${felhasznalo.value}' AND f.jelszo = '${hash}' AND f.email = '${email.value}'`;
            LekerdezesEredmenye(sql2).then((valasz) => {
                if (valasz) {
                    console.log(valasz);
                    alert("Sikeres regisztráció");
                    let nev = document.getElementById("regFf").value;
                    FooldalgenReg(nev,email);
                    sessionStorage.setItem("email",valasz[0].email);
                    sessionStorage.setItem("fn",valasz[0].felhasznaloNev);
                    sessionStorage.setItem("login",true);
                    sessionStorage.setItem("osztaly",valasz[0].osztaly);
                    sessionStorage.setItem("jog",valasz[0].jog);
                    sessionStorage.setItem("login",true);
                } else {
                    alert("Nem sikerült a regisztráció");
                }
            });
    });
    }
    //------------
}

function JelszoMegvizsgal(jelsz1,jelsz2)
{
    if(jelsz1 != jelsz2)
    {
        alert("nem egyezik a jelszo");
        location.reload();
    }
}
function ErosE(jelsz, felhasz) {
  if (jelsz.includes(felhasz)) {
      return false; 
  }

  if (jelsz.length < 5 || jelsz.length > 16) {
      return false;
  }

  let kicsi = false;
  let nagy = false;
  let szam = false;
  let spec = false;
  for (let i = 0; i < jelsz.length - 2; i++) {
      if (jelsz[i].charCodeAt() + 1 === jelsz[i + 1].charCodeAt() && jelsz[i + 1].charCodeAt() + 1 === jelsz[i + 2].charCodeAt()) {
          return false;
      }
  }
  for (let i = 0; i < jelsz.length; i++) {
      if (/[a-z]/.test(jelsz[i])) {
          kicsi = true;
      } else if (/[A-Z]/.test(jelsz[i])) {
          nagy = true;
      } else if (/[0-9]/.test(jelsz[i])) {
          szam = true;
      }else if(/[\.\_]/.test(jelsz[i])){
          spec = true;
      }
      else
      {
          return false;
      }
  }
  return kicsi && nagy && szam && spec;
}

function BejelentkezesGen()
{
    let kartya = document.getElementById("kartya");
    kartya.innerHTML =" ";
    kartya.innerHTML = `
    <br>
    <h1>Bejelentkezés</h1>
    <br>
    <form id="regForm" class="col-6 col-sm-12">
      <label for="regem">E-mail</label>
      <br>
      <input type="email" class="form-control" id="regem" placeholder="E-mail">
      <br>
      <label for="fnjelsz">Jelszó</label>
      <br>
      <input type="password" class="form-control" id="fnjelsz" placeholder="Jelszó">
      <br>
      <div class="text-center">
      <input type="button" class="btn btn-light col-12" value="Bejelentkezés" onclick="Login()"><br>
      <a onclick="RegGen()" id="reg">Nincs még fiókom</a>
      <br>
      <a onclick="Login()" id="elfjeszo">Elfelejtettem a jelszavam</a>
  </form>
  `;
}

function RegGen()
{
    let kartya = document.getElementById("kartya");
    kartya.innerHTML =" ";
    kartya.innerHTML =`
    <br>
    <h1>Regisztráció</h1>
    <br>
    <form id="regForm" class="col-6 col-sm-12">
    <label for="regfn">Felhasználónév</label>
    <br>
    <input type="text" class="form-control" placeholder="Felhasználónév" id="regFf">
    <label for="regem">E-mail</label>
    <br>
    <input type="email" class="form-control" id="regem" placeholder="E-mail">
    <br>
    <label for="regem">Osztály</label>
    <br>
    <input type="text" class="form-control" id="regem" placeholder="12C">
    <br>
    <label for="fnjelsz">Jelszó</label>
    <br>
    <input type="password" class="form-control" id="fnjelsz" placeholder="Jelszó">
    <br>
    <input type="password" class="form-control" id="fnjelszujra" placeholder="Jelszó újra">
    <br>
    <div class="text-center">
    <input type="button" class="btn btn-light col-12" value="Regisztráció" onclick="regisztracio()">
    <br>
    <a onclick="BejelentkezesGen()" id="bejelentkezes">Van már fiókom</a>
  </div>`;

}
