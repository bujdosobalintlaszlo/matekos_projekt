function FooldalgenReg(nev,email){
    document.body.innerHTML +="";
    document.body.innerHTML =`<nav class="navbar navbar-expand-lg" id="nav">
    <div class="container-fluid">
      <a class="navbar-brand" href="#" id="fnhely"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
      <span><li class="nav-item">
        <input type="button" value="Feladatok" class="btn btn-light terKoz" onclick="Feltoltes()">
      </li></span>
      <span><li class="nav-item">
        <input type="button" value="Dolgozatok" class="btn btn-light terKoz" onclick="DolgozatokGen()">
      </li></span>
      <span><li class="nav-item">
        <input type="button" value="Kijelentkezés" class="btn btn-light terKoz" onclick="Kijelentkezes()">
      </li></span>
      <span style="display :none" id="feltoltes"><li class="nav-item">
        <input type="button" value="Feltöltés" class="btn btn-light terKoz" onclick="Feltoltes()">
      </li></span>
      <span id="lenyilo"><li class="nav-item">
      <span><li class="nav-item"><div class="dropdown">
      <button class="btn btn-secondary dropdown-toggle terKoz" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        Témák
      </button>
      <ul class="dropdown-menu" id="temakor">
        </ul>
  </div>
    </ul>
      </li></span>
      </div>
      </div>
    </div>
  </nav>
  </div>
    <div class="container col-12" id="jobb">
    </div>
    </div>
    `;
  KategoriakGen();
  let sql = `select f.jog from felhasznalok f where f.email = '${email}'`;
  console.log(sql);
  LekerdezesEredmenye(sql).then((valasz) => {
    console.log(valasz);
    if (valasz[0].jog == "1") {
        document.getElementById("feltoltes").style.display="block";
      }
  });
  document.getElementById("fnhely").innerHTML=nev;
  FeladatListaz();
  
  }
//Feladatok az adatbázisból  
var feladatok = [];

//Adatbázisból lekéri az összes feladatot, ezeket pedig a feladatok tömbben tárolja el.
function FeladatListaz() {
let sqlFeladatok = `Select * from feladatok`;

LekerdezesEredmenye(sqlFeladatok).then((valasz) => {
    valasz.forEach(adat => {
        feladatok.push({
            id: adat.id,
            temakorId: adat.temakorID,
            megoldas: adat.megoldas,
            nehezseg: adat.nehezseg,
            pontszam: adat.pontszam,
            nev: adat.nev
        });
    });
    console.log(feladatok);
    FeladatokFeltolt("jobb");
});
}

function FeladatokFeltolt(divId) {
    var hely = document.getElementById(divId);
    feladatok.forEach(adattag => {
        let div = document.createElement("div");
        div.id = adattag.id;
        div.classList.add("feladat");
        div.classList.add("col-12");
        div.classList.add("row");

        let szinResult = Szinez(adattag.nehezseg);
        div.innerHTML = `
            <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}">
                <p>${adattag.id}.</p>
            </div>
            <div class="feladatNev col-5">
                <p>${adattag.nev}</p>
            </div>
            <div class="feladatTemakor col-5 d-none d-xs-block">
            <p id="${adattag.id}temakorP"></p>
        </div>
        

        `;
        TemakorBeiir(adattag.temakorId,`${adattag.id}temakorP`);
        hely.appendChild(div);
        hely.appendChild(document.createElement("br"));
    });
}

function TemakorBeiir(id, pId){
    let sql = `select temakor from temakor t where t.id = ${id}`;
    LekerdezesEredmenye(sql).then((valasz) =>{
        console.log(valasz[0].temakor);
        document.getElementById(pId).innerHTML = valasz[0].temakor;    
    });
}

  
//A kártyák nehézségi színtjét jelzi színekkel. Ezt nehézség alapján dönti el.
function Szinez(nehezseg) 
{
let result = {
    color: "",
    text: ""
};

if (nehezseg == "0") {
    result.color = "green";
    result.text = "Középszint";
} else if (nehezseg == "1") {
    result.color = "orange";
    result.text = "Emeltszint";
} else if (nehezseg == "2") {
    result.color = "red";
    result.text = "Verseny feladat";
} else {
    result.color = "black";
    result.text = "-";
}

return result;
}
  
  //Kijelentkezés(sessionstorage ürítés + frissíti az oldalt)
function Kijelentkezes(){
sessionStorage.clear();
location.reload();
}
  
//Oldalfrissítés esetén meghívja a BejelentkezettE() functiont ami eldöndi, hogy be van-e jelenkezve és annak megfelelően generálja ki az oldalt. 
window.onload = function() {
BejelentkezettE();
};

//Frissítés utáni generálás bejelentkezési állapottól függően
function BejelentkezettE() {
const nev = sessionStorage.getItem("fn");
const email = sessionStorage.getItem("email");
if (nev && email) {
    FooldalgenReg(nev, email);
} else {
    console.log("Nem vagy bejelentkezve!");
}
}

//Dropdown menüben lévő kategóriák kigenerálása
function KategoriakGen(){
var hely = document.getElementById("temakor");
let sql = `select * from temakor`
LekerdezesEredmenye(sql).then((valasz) =>{
    valasz.forEach(elem =>{
        hely.innerHTML +=
        `<div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="${elem.id}temakor" onclick="Szures()">
                <label class="form-check-label" for="flexCheckDefault">${elem.temakor}</label>
        </div>`;
        });
    }); 
}