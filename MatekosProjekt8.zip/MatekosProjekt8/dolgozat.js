var jelenlegi;
var dolgozatIdTomb = [];
var kell = [];
var osztalyok = [];
var idokorlat = "";
var dolgozate = false;
function DolgozatokGen(){
    document.body.innerHTML="";
    document.body.innerHTML = `
    <nav class="navbar navbar-expand-lg" id="nav">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
           <span>
           <form class="d-flex col-12" role="search">
            <input class="form-control me-2" type="search" placeholder="Keresés" aria-label="Search" id="kerszo" onkeyup="Talal()">
          </form>
           </span>
            <span>
            <input type="button" value="Összes" style="color:black;" class="btn btn-light terKoz" id="osszes" onclick="Osszes2()">
      <input type="button" value="Középszint" style="color:green;" class="btn btn-light terKoz" id="konnyuSzur" onclick="KozepSzur2()">
      <input type="button" value="Emeltszint" style="color:orange" class="btn btn-light terKoz" id="emeltSzur" onclick="EmeltSzur2()">
      <input type="button" value="Verseny feladat" style="color:red" class="btn btn-light terKoz" id="versenySzur" onclick="VersenySzur2()">
      <input type="button" value="Jelöletlen nehézség" style="color:black" class="btn btn-light terKoz" id="jelSzur" onclick="JelSzur2()">
            </span>
        <span id="lenyilo"><li class="nav-item">
      <span><li class="nav-item"><div class="dropdown">
      <button class="btn btn-light dropdown-toggle terKoz" type="button" data-bs-toggle="dropdown" aria-expanded="false">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="black" class="bi bi-bookmarks" viewBox="0 0 16 16">
  <path d="M2 4a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v11.5a.5.5 0 0 1-.777.416L7 13.101l-4.223 2.815A.5.5 0 0 1 2 15.5zm2-1a1 1 0 0 0-1 1v10.566l3.723-2.482a.5.5 0 0 1 .554 0L11 14.566V4a1 1 0 0 0-1-1z"/>
  <path d="M4.268 1H12a1 1 0 0 1 1 1v11.768l.223.148A.5.5 0 0 0 14 13.5V2a2 2 0 0 0-2-2H6a2 2 0 0 0-1.732 1"/>
</svg> Témák
      </button>
      <ul class="dropdown-menu" id="temakor">
    
        </ul>
  </div>
      </li></span>
        <span>
                <li class="nav-item">
                    <input type="button" value="Feladatlap feltöltése" class="btn btn-light terKoz" onclick="Ment()" disabled id="ment">
                </li>
        </span>
        <span>
        <li class="nav-item">
            <input type="button" value="Vissza" class="btn btn-light terKoz" onclick="Vissza()">
        </li>
    </span>
    </div>
    </div>
</nav>
    <div class="row">
      <div class="col" id="kereses">
        
      </div>
      <div class="col-md-6 col-s-12" id="feladatok">
      <h1 id="cim">
      A feladatok:
        </h1>
      </div>
    </div>
</div>`;
FeladatokFeltoltDolgozat("kereses");
KategoriakGen2();
}

function FeladatokFeltoltDolgozat(divId) {
    var hely = document.getElementById(divId);
    feladatok.forEach(adattag => {
        let div = document.createElement("div");
        div.id = adattag.id;
        div.classList.add("feladat");
        div.classList.add("col-12");
        div.style.marginBottom="20px";     
        let szinResult = Szinez(adattag.nehezseg);
        div.innerHTML = `
            <div id="maindiv${adattag.id}" data-adattag="jobbra" class="sorszam col-3 text-center" style="background-color: ${szinResult.color}" onclick="Hozzaad(this,${adattag.id})">
                <p id="svg${adattag.id}"><svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
                <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
              </svg></p>
            </div>
            <div class="feladatNev col-5">
                <p>${adattag.nev}</p>
            </div>
            <div class="feladatTemakor col-5">
                <p id="temakorP"></p>
            </div>
        `;
        TemakorBeiir(adattag.temakor);
        hely.appendChild(div);
    });
  }
  function FeladatokFeltoltDolgozat2(hely,divId) {
    var hely = document.getElementById(hely);
        let div = document.createElement("div");
        div.id = `doga${divId-1}`;
        div.classList.add("feladat");
        div.classList.add("col-12");     
        let szinResult = Szinez(feladatok[divId-1].nehezseg);
        div.innerHTML = `
            <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}" onclick="hozzaad(${divId-1},'jobbra')">
                <p id="svg${adattag.id}"><svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-dash" viewBox="0 0 16 16">
                <path d="M4 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 4 8"/>
              </svg></p>
            </div>
            <div class="feladatNev col-5">
                <p>${feladatok[divId-1].nev}</p>
            </div>
            <div class="feladatTemakor col-5">
                <p id="temakorP"></p>
            </div>
        `;
        TemakorBeiir(feladatok[divId-1].temakorId);
        hely.appendChild(div);
        hely.appendChild(document.createElement("br"));
  }
  //meg tombbe kell menteni mi kerul be
  function Hozzaad(elem,id){
      if(elem.dataset.adattag == "jobbra"){
          kell.push(id);
          console.log(kell);
          document.getElementById("feladatok").appendChild(elem.parentElement);
          document.getElementById(`svg${id}`).innerHTML="";
          document.getElementById(`svg${id}`).innerHTML=`<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-dash" viewBox="0 0 16 16">
          <path d="M4 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 4 8"/></svg>`;
          document.getElementById(`maindiv${id}`).dataset.adattag = "balra";
      }
      else if(elem.dataset.adattag == "balra"){
        let indexToRemove = kell.indexOf(id);
        if (indexToRemove !== -1) {
            kell.splice(indexToRemove, 1);
            console.log(kell);
        }
        document.getElementById("kereses").appendChild(elem.parentElement);
        document.getElementById(`svg${id}`).innerHTML="";
        document.getElementById(`svg${id}`).innerHTML=`<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
        <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
      </svg>`;    
      document.getElementById(`maindiv${id}`).dataset.adattag = "jobbra";
      console.log("vissza");
      }
      if(kell.length > 0){
        document.getElementById("ment").disabled = false;
      }else{
        document.getElementById("ment").disabled = true;
      }
}
  function MegjelenitHozzaadottFeladat(arr,hely){
    
    document.getElementById(hely).innerHTML ="";
    for (let index = 0; index < arr.length; index++) {
        FeladatokFeltoltDolgozat2(hely,arr[index]);
    }
  }
  
  function KartyaTorol(ind){
      if(!dolgozatIdTomb.includes(ind)){
          document.getElementById(ind).remove();
      }
  }
  

function FeladatKartyaGen(divId,hely)
{
    let index = divId-1;
    console.log(hely);
    var hely = document.getElementById(hely);
    hely.innerHTML ="";
    var div = document.createElement("div");
    let szinResult = Szinez(feladatok[index].temakorId);
    div.innerHTML = `
        <div class="sorszam" id="${feladatok[index].id}" style="background-color: ${szinResult.color}">
            <p class=" col-1">${feladatok[index].id}.</p>
        </div>
        <div class="col-11 col-sm-7">
            <p class="feladatNevP">${feladatok[index].nev}</p>
        </div>
        <div class="col-sm-4  d-none d-sm-block ">
            ${SzambolTemakor(index)}
        </div>`;
    hely.appendChild(div);
    hely.appendChild(document.createElement("br"));
    
}
function SzambolTemakor (index){
    let sql = `select t.temakor as tema from temakor t where t.id = ${feladatok[index].temakorId}`;
    LekerdezesEredmenye(sql).then((valasz)=>{
        let p = document.createElement("p");
        p.classList.add("temakorP");
        p.innerHTML=valasz[0].tema;
    });
}
function Ment(){
    document.body.innerHTML="";
    document.body.innerHTML=`
    <form>
    <div class="mb-3" id="feladatnev">
      <label for="feladatnevinfo" class="form-label">Addja meg a feladatsor nevét!</label>
      <input type="text" class="form-control" id="feladatnevinfo" aria-describedby="feladatlpaneve">
      <div id="feladatlapnevkot" class="form-text">(Kötelező!)</div>
      <label for="megoldasiidolable" class="form-label">Időkorlát</label>
      <input type="time" class="form-control" id="megoldasiido" aria-describedby="megoldasiido">
      <div id="megoldasihatkot" class="form-text">(Nem Kötelező!)</div>
      <label for="hataridolabel" class="form-label">Határidő</label>
      <input type="date" class="form-control" id="hatarido" aria-describedby="hatarido">
      <div id="hataridkot" class="form-text">(Nem Kötelező!)</div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="flexCheckIndeterminate" onclick="DolgozatE()">
        <label class="form-check-label" for="flexCheckIndeterminate">
            Dolgozat?
        </label>
        </div>
      <div class="dropdown">
    <a id="osztalyok" class="btn btn-secondary dropdown-toggle col-12" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        Osztályok
    </a>

    <ul class="dropdown-menu col-12" id="osztalyokvalaszt">
        
    </ul>
    </div>
    </div>
    </form>
    <div id="feladatsorDisplay">
    </div>
    <div id="jovahagydiv">
    <input id="jovahagy" class="btn btn-secondary dropdown-toggle col-12" type="button" value="Jóváhagy" onclick="Felkuld()">
    <input id="visszadoga" class="btn btn-secondary dropdown-toggle col-12" type="button" value="Vissza" onclick="VisszaDolgozatOsszeallitashoz()">
    </div>
    
    `;
   
    FeladatDisplay();
    OsztalyokBeir();
}
var pontok =0;
function FeladatDisplay(){
    var osszeg = 0;
    var length = kell.length;
    var hely = document.getElementById("feladatsorDisplay");
    var promises = [];

    for(var i = 1; i <= length; ++i){
        var promise = FeladatInfo(i).then((valasz) => {  
            console.log(parseInt(valasz.pontszam));  
            osszeg += parseInt(valasz.pontszam);
            console.log(osszeg);
            hely.innerHTML += `<div id="megjelenfeladat${i}">
                <p style="margin:20px">Feladat neve: ${valasz.nev}, Kategória: ${valasz.tema}, Pontszám: ${valasz.pontszam} pont.<br><hr></p>
            </div>`;
        });
        promises.push(promise);
    }
    Promise.all(promises).then(() => {
        hely.innerHTML +=`<div id ="osszeg"></div>`;
        pontok = osszeg;
        AdatokGen(osszeg);
        console.log(pontok + "- pontok");
    });
}

function AdatokGen(osszeg){
    var hely = document.getElementById("osszeg");
    hely.innerHTML += `<p>Összes pontszám: ${osszeg}</p>`;
}

async function FeladatInfo(i) {
    let sql = `SELECT f.*, t.temakor AS tema 
               FROM feladatok f 
               JOIN temakor t ON f.temakorId = t.id 
               WHERE f.id = ${i}`;
    console.log(sql);
    return LekerdezesEredmenye(sql).then((x) => {
        console.log(x);
        return x[0];
    });
}

function OsztalyokBeir()
{
    let sql = `Select distinct f.osztaly as o from felhasznalok f where f.osztaly != "" and f.osztaly != "nan"`;
    var hely = document.getElementById("osztalyokvalaszt");
    LekerdezesEredmenye(sql).then((osztalyok) =>{
        for(let i=0; i< osztalyok.length;++i){
            hely.innerHTML +=`
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="osztaly${i}" onclick="OsztalyKezel('${osztalyok[i].o}')">
            <label class="form-check-label" for="flexCheckIndeterminate">
              ${osztalyok[i].o}
            </label>
          </div>`;
        }
    });
}


function OsztalyKezel(osztaly) {
    const index = osztalyok.indexOf(osztaly);
    if (index !== -1) {
        osztalyok.splice(index, 1);
    } else {
        osztalyok.push(osztaly);
    }
}


function Felkuld()
{
    let nev = document.getElementById("feladatnevinfo").value;
    let sql = "";
    let megoldido = document.getElementById("megoldasiido").value;
    let hatarido = document.getElementById("hatarido").value;
    /*
    if(FeladatlapNevCheck(nev)){
        for(let i=0;i<osztalyok;++i){
            sql += "Insert into feladatsor f Values(null,)";
        }
    }else{
        alert("A név már foglalt");
    }
    */
}

function FeladatlapNevCheck(nev){
    let sql = `Select ffk.FeladatNev as fnev from feladatsor f,feladatesfeladatsorkapcs ffk where feladatsor.id = ffk.feladatsorId`;
    LekerdezesEredmenye(sql).then((nevek)=>{
        if(nevek.includes(nev)){
            return false;
        }else{
            return true;
        }
    });
}

function DolgozatE(){
    !dolgozate ? dolgozate = true : dolgozate = false;
    console.log(dolgozate);
}

async function TemakorSzures2(id) {
    szurt=[];
    const length = await TemakorCount();
    for (let index = 1; index <= length; index++) {
        if (document.getElementById(`${index}`).checked) {
            szurt = szurt.concat(feladatok.filter(x => x.temakorId == index));
        }
    }
    if (szurt.length==0) {
        szurt=feladatok;
    }
    eredetiSzurt=szurt;
    MegjelenitItems2();
}




function VisszaDolgozatOsszeallitashoz()
{
    DolgozatokGen();
}


