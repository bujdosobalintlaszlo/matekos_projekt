function Feltoltes()
{
  document.body.innerHTML +="";
  document.body.innerHTML =`<nav class="navbar">
  <div class="container-fluid">
    <span class="navbar-brand mb-0 h1"><button type="button" class="btn btn-light" onclick="VisszaMenu()">Vissza</button></span>
  </div>
</nav>
<div id="tartalom">
  <div class="row row-cols-2">
    <div class="col-12 col-xl-6">
      <form id="hozaadasForm">
        <div class="mb-3">
          <label for="hozaadasForm" class="form-label"><h3><b>Feladat neve</b><span id="infoSpan" onmouseover="showHovered()" onmouseout="hideHovered()">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
              <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
              <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
          </svg>
      </span>
      <span id="hoveredInfoSpan" onclick="Info()" data-bs-toggle="modal" data-bs-target="#feladatmodal">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle-fill" viewBox="0 0 16 16">
              <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2"/>
          </svg>
      </span></h3></label>
          <textarea class="form-control" id="feladatNevForm" rows="1" maxlength="50" onkeyup="BeirCim()"></textarea>
        </div>
        <div class="mb-1">
          <label for="hozaadasForm" class="form-label"><h3><b>Feladat szövege:</b></h3></label>
          <textarea class="form-control" id="feladatForm" rows="3" maxlength="500" onkeyup="BeirFeladat()"></textarea>
        </div>
        <div class="mb-2">
          <label for="hozaadasForm" class="form-label"><h3><b>Megoldás:</b></h3></label>
          <textarea class="form-control" id="megoldasForm" rows="1" maxlength="250" onkeyup="BeirMegoldas()"></textarea>
        </div>
        <div class="mb-3">
          <label for="hozaadasForm" class="form-label"><h3><b>Nehézségi szint:</b></h3></label>
          <textarea class="form-control" id="szintForm" rows="1" maxlength="250" onkeyup="BeirNehezeseg()"></textarea>
        </div>
        <div class="mb-3">
          <label for="hozaadasForm" class="form-label"><h3><b>Kategória:</b></h3></label>
          <textarea class="form-control" id="kategoriaForm" rows="1" maxlength="250" onkeyup="BeirKategoria()"></textarea>
        </div>
        <div class="mb-3">
          <label for="hozaadasForm" class="form-label"><h3><b>Pontszám:</b></h3></label>
          <textarea class="form-control" id="pontszamForm" rows="1" maxlength="250" onkeyup="BeirPontszam()"></textarea>
        </div>
      </form>
      <input type="button" value="Jóváhagy" onclick="Jovahagy()">
    </div>
    <div class="col-12 col-xl-6" id="megjelenit"><h3><b>Megjelenés:</b></h3>
    <h3 id="FeladatNev"></h3>
    <p id="szint"></p><br>
    <p id="feladat"></p>
    <p>Válasz:</p><input type="text" id="megoldas" disabled class="col-12">
    <p id="kategoria">Kategória:</p>
    <p id="pontszam"></p>
  </div>
</div>
</div>
<div class="modal fade" id="feladatmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" data-bs-theme="dark">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Regisztrációhoz hasznos lehet:</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <h4>A Feladat neve ne legyen olyan hogy...</h4>
          <ul>
              <li style="margin-left: 20px;"><b>(Pl.: 87old. 5)</b>, mivel nem lehet tudni melyik tankönyv és a későbbiekben zavart okozhat!</li>
              <li style="margin-left: 20px;"><b>Házi feladat</b></li>
              <li style="margin-left: 20px;"><b>1. feladat</b> vagy ehhez hasonló</li>
              <li style="margin-left: 20px;">A <b>témakör neve</b> (pl.: Kombinatorika vagy kombinatorika 1)</li>
              <li style="margin-left: 20px;">2023 máj. 10 <b>középszint</b>, mivel azt külön mezőben kell megadni!</li>
          </ul>
          <h4>A feladat neve legyen...</h4>
          <ul>
              <li style="margin-left: 20px;"><b>Tömör</b>, lényegretörő</span></li>
              <li style="margin-left: 20px;">Akár tankönyvből is csak <b>pontos névvel</b>. (Pl.: Egységes matekérettségi fgy. II. 237 old. 2347)</span></li>
              <li style="margin-left: 20px;">Akár érettségi, versenyfeladat <b>pontos vévvel</b>. (Pl.: 2023 máj.10).</span></li>
          </ul>
      </div>
      
      <br>
    </div>
  </div>
</div>`;
}

function BeirCim()
{
    var nev = document.getElementById("feladatNevForm").value;
    console.log(nev);
    document.getElementById("FeladatNev").innerHTML = `${nev}`;
}
function BeirKategoria()
{
  var kat = document.getElementById("kategoriaForm").value;
  document.getElementById("kategoria").innerHTML = `Kategória: ${kat}`;
}
function BeirFeladat() {
  var feladatInput = document.getElementById("feladatForm").value;
  var output = document.getElementById("feladat");
  output.innerHTML = `<span>${feladatInput}</span>`;
  typesetOutput(output);
}
function typesetOutput(outputElement) {
  MathJax.texReset();
  MathJax.typesetClear();
  MathJax.typesetPromise([outputElement]).catch(function (err) {
      outputElement.innerHTML = '';
      outputElement.appendChild(document.createTextNode(err.message));
      console.error(err);
  });
}
window.MathJax = {
  loader: {load: ['input/asciimath']},
  startup: {
    pageReady: function () {
        var input = document.getElementById('feladatForm');
        var output = document.getElementById('feladat');
        output.innerHTML = input.value.trim();
        window.typesetInput = function () {
          output.innerHTML = input.value.trim();
          MathJax.texReset();
          MathJax.typesetClear();
          MathJax.typesetPromise([output]).catch(function (err) {
            output.innerHTML = '';
            output.appendChild(document.createTextNode(err.message));
            console.error(err);
          });
        }
        input.oninput = typesetInput;
      }
  },
  tex: {
    inlineMath: [['$', '$'], ['\\(', '\\)']],
    processEscapes: true
  }
};
var script = document.createElement('script');
script.src = 'https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js';
script.setAttribute('id', 'MathJax-script');
document.head.appendChild(script); 

function BeirMegoldas()
{
    var nev = document.getElementById("megoldasForm").value;
    console.log(nev);
    document.getElementById("megoldas").placeholder = `${nev}`;
}

function BeirNehezeseg()
{
    var nehezseg = document.getElementById("szintForm").value;
        nehezseg === "0" ? document.getElementById("szint").innerHTML = `Középszint` : (nehezseg === "1" ? document.getElementById("szint").innerHTML = `Emelt szint` :(nehezseg ==="2" ? document.getElementById("szint").innerHTML = `Verseny feladat` : document.getElementById("szint").innerHTML = `-`));
}

function BeirPontszam()
{
    var nev = document.getElementById("pontszamForm").value;
    console.log(nev);
    document.getElementById("pontszam").innerHTML = `${nev} pont`;
}

function VisszaMenu()
{
  location.reload();
}


  function Jovahagy()
  {
    let sql =`Insert into feladatok values(null,${document.getElementById("kategoriaForm").value},'${document.getElementById("megoldasForm").value}',${document.getElementById("szintForm").value},${document.getElementById("pontszamForm").value.replace("pont","")},'${document.getElementById("feladatNevForm").value}','${document.getElementById("feladatForm").value}') `;
    console.log(sql); 
    LekerdezesEredmenye(sql).then((valasz) =>{
      console.log(valasz);
    });
  }

  function showHovered() {
    document.getElementById('infoSpan').style.display = 'none';
    document.getElementById('hoveredInfoSpan').style.display = 'inline';
}

function hideHovered() {
    document.getElementById('infoSpan').style.display = 'inline';
    document.getElementById('hoveredInfoSpan').style.display = 'none';
}


function Info()
{

}

