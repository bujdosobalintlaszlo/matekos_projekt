var limit = 0;
var jo = false;
var fooldaoldalszam3 = 1;

function RangLista() {
 document.body.innerHTML="";
 var div =  document.createElement("div");
 div.id="TablaHely";
 document.body.appendChild(div);
 CreateTable("TablaHely", "ranglista");
  var hely = document.getElementById("ranglista");
  hely.innerHTML += `
    <thead>
      <tr>
        <th>Helyezés</th>
        <th>Felhasználónév</th>
        <th>Megoldott feladatok</th>
      </tr>
    </thead>
    <tbody id="ranglista-tbody"></tbody>`;
  
  let sql = `SELECT f.id AS felhasznalo_id, f.FelhasznaloNev AS felhasznalo_nev,COALESCE(COUNT(ff.feladatId), 0) AS megoldott_feladatok_szama,COALESCE(MIN(ff.megoldIdo), '9999-12-31') AS legkorabbi_megoldIdo,
    RANK() OVER (ORDER BY 
        COALESCE(COUNT(ff.feladatId), 0) DESC, 
        COALESCE(MIN(ff.megoldIdo), '9999-12-31') ASC
    ) AS helyezes,
    CASE 
      WHEN COUNT(ff.feladatId) = 0 THEN 'nincs megoldott feladat'
      ELSE 'van megoldott feladat'
    END AS felhasznalo_tipus
  FROM 
    felhasznalok f
  LEFT JOIN 
    felhaszesfeladkapcs ff ON f.id = ff.felhasznaloId 
  GROUP BY 
    f.id, f.FelhasznaloNev
  ORDER BY 
    helyezes
    LIMIT 15 OFFSET ${limit};
  `;
console.log(sql);
  LekerdezesEredmenye(sql).then((x) => {
    let tbody = document.getElementById("ranglista-tbody");
    x.forEach(element => {
      console.log(element.felhasznalo_id);
      tbody.innerHTML += `
        <tr>
        <td style="${element.felhasznalo_id == sessionStorage.fnid ? 'background-color: green;' : ''}">${element.helyezes}</td>
          <td>${element.felhasznalo_nev}</td>
          <td>${element.megoldott_feladatok_szama}</td>
        </tr>`;
    });
  });

    document.body.innerHTML+=`<nav aria-label="Page navigation example" id="oldalvalto">
  <ul class="pagination justify-content-center">
    <li class="page-item">
      <a class="page-link" id="elozo" onclick="Elozo3()">Visszaugrás</a>
    </li>
    <li class="page-item" onclick="SzamClick3(this.querySelector('a').id)"><a class="page-link" id="elso">1</a></li>

    <li class="page-item" onclick="SzamClick3(this.querySelector('a').id)"><a class="page-link" id="masodik">2</a></li>
    <li class="page-item" onclick="SzamClick3(this.querySelector('a').id)" ><a class="page-link" id="harmadik">3</a></li>
    <li class="page-item">
      <a class="page-link" id="kovetkezo" onclick="Kovetkezo3()">Előreugrás</a>
    </li>
  </ul>
</nav>
<span class="navbar-brand mb-0 h1">
<button type="button" class="btn btn-light" onclick="FooldalgenReg('${sessionStorage.fn}', '${sessionStorage.email}')">Vissza</button>
</span>`;
}
function RanglistaMutat(){
  var hely = document.getElementById("ranglista");
  hely.innerHTML = `
    <thead>
      <tr>
        <th>Helyezés</th>
        <th>Felhasználónév</th>
        <th>Megoldott feladatok</th>
      </tr>
    </thead>
    <tbody id="ranglista-tbody"></tbody>`;
  
  let sql = `SELECT f.id AS felhasznalo_id, f.FelhasznaloNev AS felhasznalo_nev,COALESCE(COUNT(ff.feladatId), 0) AS megoldott_feladatok_szama,COALESCE(MIN(ff.megoldIdo), '9999-12-31') AS legkorabbi_megoldIdo,
    RANK() OVER (ORDER BY 
        COALESCE(COUNT(ff.feladatId), 0) DESC, 
        COALESCE(MIN(ff.megoldIdo), '9999-12-31') ASC
    ) AS helyezes,
    CASE 
      WHEN COUNT(ff.feladatId) = 0 THEN 'nincs megoldott feladat'
      ELSE 'van megoldott feladat'
    END AS felhasznalo_tipus
  FROM 
    felhasznalok f
  LEFT JOIN 
    felhaszesfeladkapcs ff ON f.id = ff.felhasznaloId 
  GROUP BY 
    f.id, f.FelhasznaloNev
  ORDER BY 
    helyezes
    LIMIT 15 OFFSET ${limit};
  `;
console.log(sql);
  LekerdezesEredmenye(sql).then((x) => {
    let tbody = document.getElementById("ranglista-tbody");
    x.forEach(element => {
      console.log(element.felhasznalo_id);
      tbody.innerHTML += `
        <tr>
        <td style="${element.felhasznalo_id == sessionStorage.fnid ? 'background-color: green;' : ''}">${element.helyezes}</td>
          <td>${element.felhasznalo_nev}</td>
          <td>${element.megoldott_feladatok_szama}</td>
        </tr>`;
    });
  });
}
function CreateTable(hely, id) {
  if (hely == null) {
    document.body.innerHTML = `<div id="tablaHely"><table class="table table-dark table-striped" id='${id}'></table></div>`;
  } else {
    document.getElementById("TablaHely").innerHTML += `<table class="table table-dark table-striped" id='${id}'></table>`;
  }
}


function SzamClick3(id) {
  if (id == "elso") {
    fooldaoldalszam3 = parseInt(document.getElementById("elso").innerHTML);
  } else if (id == "masodik") {
    fooldaoldalszam3 = parseInt(document.getElementById("masodik").innerHTML);
  } else if (id == "harmadik") {
    fooldaoldalszam3 = parseInt(document.getElementById("harmadik").innerHTML);
  }
  limit = (fooldaoldalszam3 - 1) * 15;
  //document.getElementById("TablaHely").innerHTML =""; 
  RanglistaMutat();
}

function Elozo3() {
  let elso = document.getElementById("elso");
  let masodik = document.getElementById("masodik");
  let harmadik = document.getElementById("harmadik");
  if (parseInt(elso.innerHTML) > 1) {
    elso.innerHTML = `${parseInt(elso.innerHTML) - 3}`;
    masodik.innerHTML = `${parseInt(masodik.innerHTML) - 3}`;
    harmadik.innerHTML = `${parseInt(harmadik.innerHTML) - 3}`;
    limit = (parseInt(elso.innerHTML) - 1) * 15;
    fooldaoldalszam3 = parseInt(elso.innerHTML);
   //document.getElementById("TablaHely").innerHTML =""; 
   RanglistaMutat();
  }
}

function Kovetkezo3() {
  let elso = document.getElementById("elso");
  let masodik = document.getElementById("masodik");
  let harmadik = document.getElementById("harmadik");
  elso.innerHTML = `${parseInt(elso.innerHTML) + 3}`;
  masodik.innerHTML = `${parseInt(masodik.innerHTML) + 3}`;
  harmadik.innerHTML = `${parseInt(harmadik.innerHTML) + 3}`;
  limit = (parseInt(elso.innerHTML) - 1) * 15;
  fooldaoldalszam3 = parseInt(elso.innerHTML);
 // document.getElementById("TablaHely").innerHTML =""; 
  RanglistaMutat();
}