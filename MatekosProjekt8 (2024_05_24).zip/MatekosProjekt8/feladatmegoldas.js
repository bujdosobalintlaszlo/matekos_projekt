var ajanlott = false;
var hasonlofeladatok = [];
window.MathJax = {
    loader: { load: ['input/asciimath'] },
    tex: {
        inlineMath: [['$', '$'], ['\\(', '\\)']],
        processEscapes: true
    }
};

var script = document.createElement('script');
script.src = 'https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js';
script.setAttribute('id', 'MathJax-script');
document.head.appendChild(script);

function formatMathJax(inputId, outputId) {
    var input = document.getElementById(inputId);
    var output = document.getElementById(outputId);
    output.innerHTML = input.innerHTML.trim();
    MathJax.typesetPromise([output]).catch(function (err) {
        output.innerHTML = '';
        output.appendChild(document.createTextNode(err.message));
        console.error(err);
    });
}

function FeladatMegjelenit() {
  
    ajanlott = false;
    var feladatId = parseInt(this.id);
    var feladat = feladatok[feladatId - 1].feladat;
    document.body.innerHTML = `
    <nav class="navbar navbar-expand-lg" id="nav">
    <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
        <button data-bs-toggle="offcanvas" href="#offcanvasExample" aria-controls="offcanvasExample" class="btn btn-light terKoz" onclick="HasonloFeladatokGen(${feladatId-1}, '${feladatok[feladatId-1].temakorId}')">


            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="blue" class="bi bi-list" viewBox="0 0 16 16">
              <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5"/>
            </svg> Feladatok
          </button>
          <button class="btn btn-light terKoz" type="button" data-bs-toggle="dropdown" aria-expanded="false" onclick="FooldalgenReg('${sessionStorage.fn}', '${sessionStorage.email}')">
            Vissza a főoldalra
          </button>
          <button class="btn btn-light terKoz" type="button" data-bs-toggle="dropdown" aria-expanded="false" onclick="Kijelentkezes()">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="orange" class="bi bi-person-x" viewBox="0 0 16 16">
              <path d="M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0M8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4m.256 7a4.5 4.5 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10q.39 0 .74.025c.226-.341.496-.65.804-.918Q8.844 9.002 8 9c-5 0-6 3-6 4s1 1 1 1z"/>
              <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m-.646-4.854l.646.647.646-.647a.5.5 0 0 1 .708.708l-.647.646.647.646a.5.5 0 0 1-.708.708l-.646-.647-.646.647a.5.5 0 0 1-.708-.708"/>
            </svg> Kijelentkezés
          </button>
        </div>
      </div>
      <a class="navbar-brand ml-auto" id="nev">${sessionStorage.fn}</a>
    </div>
  </nav>
  <h1 id="cim" style="margin: 10px 20px;">${feladatId}. feladat: ${feladatok[feladatId - 1].nev}</h1>
<div id="feladat" style="margin: 0px 20px 5px 25px;">${feladat}</div>
<br>
<input type="text" id="valasz" style="width: calc(100% - 40px); margin: 0px 20px 15px 20px;">
<br>
<input type="button" value="Leadás" onclick="Lead(${this.id})" class="btn btn-dark col-12" style="width: calc(100% - 40px); margin: 0px 20px 10px 20px;">
<br>
<p style="margin: 0px 20px;">${feladatok[feladatId - 1].pontszam} pont</p>

  
        

<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasExampleLabel">Hasonló feladatok...</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body" id="hasonlo">

    
    </div>
  </div>
</div>
<div class="modal fade" id="megoldasModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body" id="megoldasModalbody">
        <h1 id="vegkimenetel"></h1>
      </div>
      <div class="modal-footer" id="megoldasModalfooter">
        <button type="button" class="btn btn-dark col-12" data-bs-dismiss="modal">Bezár</button>
      </div>
    </div>
  </div>
</div>`;

    formatMathJax('feladat', 'feladat');
}

function Lead(id) {
  var feladatId = parseInt(id);
  var sql = `select f.megoldas from feladatok f where f.id = ${feladatId}`;
  LekerdezesEredmenye(sql).then((ertek) => {
      if (ertek[0].megoldas == document.getElementById("valasz").value) {
          document.getElementById("valasz").style.border = "1px solid green";
          let vanE = `select Count(*) db from felhaszesfeladkapcs f where f.felhasznaloId = ${sessionStorage.fnid} and f.feladatId = ${feladatId}`;
          LekerdezesEredmenye(vanE).then((ertek) => {
              if (ertek[0].db == "0") {
                  var myModal = new bootstrap.Modal(document.getElementById('megoldasModal'));
                  document.getElementById("vegkimenetel").innerHTML = "Helyes a megoldás!";
                  myModal.show();

                  var sql = `select f.id from felhasznalok f where f.email = '${sessionStorage.email}'`;
                  LekerdezesEredmenye(sql).then((felhasznId) => {
                      var beszur = `Insert into felhaszesfeladkapcs values(${felhasznId[0].id}, ${feladatId}, '${datum()}')`;
                      LekerdezesEredmenye(beszur);
                  });
              } else {
                  var myModal = new bootstrap.Modal(document.getElementById('megoldasModal'));
                  document.getElementById("vegkimenetel").innerHTML = "Helyes a megoldás!";
                  myModal.show();
              }
          });
      } else {
          document.getElementById("valasz").style.border = "1px solid red";
          var myModal = new bootstrap.Modal(document.getElementById('megoldasModal'));
          document.getElementById("vegkimenetel").innerHTML = "Helytelen a megoldás!";
          myModal.show();
      }
  });
}

var datum = () => {
    var datum = new Date();
    return `${datum.getFullYear()}-${('0' + (datum.getMonth() + 1)).slice(-2)}-${('0' + datum.getDate()).slice(-2)} ${('0' + datum.getHours()).slice(-2)}:${('0' + datum.getMinutes()).slice(-2)}:00`;
};

function HasonloFeladatokGen(id, temakorid) {
  if (ajanlott === false) {
      var hely = document.getElementById("hasonlo");
      let sql = `SELECT f.* 
      FROM feladatok f
      INNER JOIN temakor t ON f.temakorId = t.id
      WHERE f.temakorId = ${temakorid} AND f.id != ${id};
      `;
      console.log(sql);
      LekerdezesEredmenye(sql).then((kapcsfeladatok) => {
          hasonlofeladatok = kapcsfeladatok;
          console.log(kapcsfeladatok);
          hasonlofeladatok.forEach(feladat => {
              console.log(feladat);
              let div = document.createElement("div");
              div.id = feladat.id;
              div.classList.add("feladat");
              div.classList.add("col-12");
              div.classList.add("row");
              div.addEventListener("click", FeladatMegjelenit);
              let szinResult = Szinez(feladat.nehezseg);
              div.innerHTML = `
                  <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}">
                      <p>${feladat.id}.</p>
                  </div>
                  <div class="feladatNev col-5">
                      <p>${feladat.nev}</p>
                  </div>
              `;
              hely.appendChild(div);
          });
      });
      ajanlott = true;
  }
}



function RandomFeladatMegjelenit(id) {  
  ajanlott = false;
  let sqlRandFeladat = `SELECT * FROM feladatok ORDER BY RAND() LIMIT 1;
  `;
  console.log("-----------------");
  console.log(sqlRandFeladat);
  console.log("-----------------");
  LekerdezesEredmenye(sqlRandFeladat).then((eredmeny) =>{
    console.log(eredmeny);
    document.body.innerHTML = `
    <nav class="navbar navbar-expand-lg" id="nav">
    <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
        <button data-bs-toggle="offcanvas" href="#offcanvasExample" aria-controls="offcanvasExample" class="btn btn-light terKoz" onclick="HasonloFeladatokGen(${eredmeny[0].id-1}, ${eredmeny[0].temakorID})">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="blue" class="bi bi-list" viewBox="0 0 16 16">
              <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5"/>
            </svg> Feladatok
          </button>
          <button class="btn btn-light terKoz" type="button" data-bs-toggle="dropdown" aria-expanded="false" onclick="FooldalgenReg('${sessionStorage.fn}', '${sessionStorage.email}')">
            Vissza a főoldalra
          </button>
          <button class="btn btn-light terKoz" type="button" data-bs-toggle="dropdown" aria-expanded="false" onclick="Kijelentkezes()">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="orange" class="bi bi-person-x" viewBox="0 0 16 16">
              <path d="M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0M8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4m.256 7a4.5 4.5 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10q.39 0 .74.025c.226-.341.496-.65.804-.918Q8.844 9.002 8 9c-5 0-6 3-6 4s1 1 1 1z"/>
              <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m-.646-4.854l.646.647.646-.647a.5.5 0 0 1 .708.708l-.647.646.647.646a.5.5 0 0 1-.708.708l-.646-.647-.646.647a.5.5 0 0 1-.708-.708"/>
            </svg> Kijelentkezés
          </button>
        </div>
      </div>
      <a class="navbar-brand ml-auto" id="nev">${sessionStorage.fn}</a>
    </div>
  </nav>
  <h1 id="cim" style="margin: 10px 20px;">${eredmeny[0].id}. feladat: ${eredmeny[0].nev}</h1>
  <div id="feladat" style="margin: 0px 20px 5px 25px;">${eredmeny[0].feladat}</div>
  <br>
  <input type="text" id="valasz" style="width: calc(100% - 40px); margin: 0px 20px 15px 20px;">
  <br>
  <input type="button" value="Leadás" onclick="Lead(${eredmeny[0].id})" id="leadasgomb" class="btn btn-dark col-12" style="width: calc(100% - 40px); margin: 0px 20px 10px 20px;">
  <br>
  <p style="margin: 0px 20px;">${eredmeny[0].pontszam} pont</p>
  
        
  
  <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasExampleLabel">Hasonló feladatok...</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body" id="hasonlo">
  
    
    </div>
  </div>
  </div>
  <div class="modal fade" id="megoldasModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body" id="megoldasModalbody">
        <h1 id="vegkimenetel"></h1>
      </div>
      <div class="modal-footer" id="megoldasModalfooter">
        <button type="button" class="btn btn-dark col-12" data-bs-dismiss="modal">Bezár</button>
      </div>
    </div>
  </div>
</div>`;
  
    formatMathJax('feladat', 'feladat');
  });
}