function Kijelentkezes()
{
    localStorage.clear();
    location.reload();
}


async function hash(string) {
    const utf8 = new TextEncoder().encode(string);
    return crypto.subtle.digest('SHA-256', utf8).then((hashBuffer) => {
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray
        .map((bytes) => bytes.toString(16).padStart(2, '0'))
        .join('');
      return hashHex;
    });
  }


const AdatbazisEleres = ()=>{
    fetch("http://127.0.0.1:3000")
    .then(function (response) {
        if (!response.ok) {
            alert("Nem jó válasz érekezett az adatbázisból");
            return Promise.reject("Nem jó válasz érekezett az adatbázisból");
        }
        return response.json();
    })
    .then(function (response) {
        if (response.Error) {
                alert(response.Error);
                console.log(response.Error);
        } else {
            alert("Az adatbázis kapcsolat él, az adatokat eléri.");
            console.log("Táblák");
            response.forEach(element => {
                console.log(element);
            });
        }
    });
}

AdatbazisEleres();

const LekerdezesEredmenye = (sql) => {
    const data = { lekerdezes: sql };
    return fetch("http://127.0.0.1:3000/lekerdezes", {
        method: "POST",
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
        },
        body: JSON.stringify(data)
    })
    .then(function (response) {
        if (!response.ok) {
            return Promise.reject("Nem jó válasz érekezett az adatbázisból");
        }
        return response.json();
    })
    .then(function (response) {
        if (response.Error) {
            return response.Error;
        } else {
            return response;
        }
    });
}


function login() {
    let fn=document.getElementById("fn").value;
    let pw=document.getElementById("pw").value;
    
    const regExpFn=/[A-Za-z0-9\.\_]{5,16}$/;
    const regExpPw=/[A-Za-z0-9\.\_]{8,16}$/;

    if (regExpFn.test(fn) && regExpPw.test(pw)) {
        hash(pw).then((hash)=> {
            let sql="select * from "+
                    "felhasznalok f "+
                    "where f.nev='"+fn+"' and "+
                    "f.jelszo='"+hash+"'";
            // let sql2=$`select * from felhasznalok f where f.nev='${fn}' and f.jelszo='${pw}'`;
            console.log(sql);
            LekerdezesEredmenye(sql).then((valasz)=>{
                console.log(valasz);
                if (valasz.length==1) {
                    localStorage.setItem("fn",valasz[0].nev);
                    localStorage.setItem("jog",valasz[0].jog);
                    localStorage.setItem("login",true);
                    let fNev=document.getElementById("fNev");
                    fNev.innerHTML=`${localStorage.getItem("fn")}`;
                    init();
                    $("#BejelentkezesModal").modal('hide');
                    //$("#BejelentkezesModal").remove(); 
                    //$('. modal-backdrop');
                }
            });
        })
    } else {
        console.log("ejnye bejnye");
    }
    
}

function regisztracio() {
    console.log("alma");
    const fn=document.getElementById("regfn");
    const info=document.getElementById("info");
    var gomb=document.getElementById("regBtn");
    gomb.disabled=true;
    info.innerHTML="";
    const regExpFn=/[A-Za-z0-9\.\_]{5,16}$/;
    let joe=true;
    let eros = true;
    if (!regExpFn.test(fn.value)) {
        info.innerHTML="Hibás felhasználónév";
        joe=false;
        gomb.disabled=true;
    } else {
        sql="select count(*) as darab from felhasznalok where nev='"+fn.value+"'";
        LekerdezesEredmenye(sql).then((valasz)=>{
            if (valasz[0].darab !=undefined && valasz[0].darab!=0) {
                info.innerHTML=`Már létezik ${fn.value} felhasználónév!`;
                gomb.disabled=true;
                joe=false;
            } 
        });
    }
    const email=document.getElementById("regemail");
    const regExpEmail=/[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$/;
    //let joe=true;
    if (joe && !regExpEmail.test(email.value)) {
        info.innerHTML +="Hibás felhasználónév";
        joe=false;
        gomb.disabled=true;
    } else {
        sql="select count(*) as darab from felhasznalok where email='"+email.value+"'";
        LekerdezesEredmenye(sql).then((valasz)=>{
            
            if (valasz[0].darab!="0") {
                info.innerHTML=`Már létezik a(z) ${email.value} E-mail cím!`;
                gomb.disabled=true;
                joe=false;
            } 
        });
    }

    const osztaly = document.getElementById("oszt");
    const osztalyRegExp = /^(9|10|11|12|13)([A-C]|K)$/;
    //console.log(osztaly.value);
    //console.log(joe);
    //console.log(!osztalyRegExp.test(osztaly.value));
    //console.log(osztaly.value!= "nan");
    if(joe && !osztalyRegExp.test(osztaly.value) && osztaly.value != "nan")
    {
        info.innerHTML +="Hibás osztály";
        joe=false;
        gomb.disabled=true;
    }

    const jelsz1=document.getElementById("regpw");//kell id
    //console.log(jelsz1.value);
    const jelsz2=document.getElementById("regpwre");
    //console.log(jelsz2.value);
    if(joe && jelsz1.value != jelsz2.value)
    {
        info.innerHTML=`A két jelszó nem egyezik!`;
        joe = false;
        gomb.disabled=true;
    }else
    {

        if(joe && !ErosE(jelsz1.value,fn.value))
        {
            info.innerHTML=`A jelszó nem megfelelő!!`;
            joe = false;
            gomb.disabled=false;
        }

    }

    if(joe)
    {
        hash(jelsz1.value).then((hash)=> {
            let sql = "INSERT INTO felhasznalok VALUES (null, '" + email.value + "', '" + hash + "','"+fn.value+"', 0, '" + osztaly.value + "');";

            console.log(sql);
            LekerdezesEredmenye(sql).then((valasz)=>{
                console.log(valasz);
                console.log("jo");
            });
    })
    }
}
function ErosE(jelsz, felhasz) {
    if (jelsz.includes(felhasz)) {
        return false; 
    }

    if (jelsz.length < 5 || jelsz.length > 16) {
        return false;
    }

    let kicsi = false;
    let nagy = false;
    let szam = false;
    let spec = false;
    for (let i = 0; i < jelsz.length - 2; i++) {
        if (jelsz[i].charCodeAt() + 1 === jelsz[i + 1].charCodeAt() && jelsz[i + 1].charCodeAt() + 1 === jelsz[i + 2].charCodeAt()) {
            return false;
        }
    }

    for (let i = 0; i < jelsz.length; i++) {
        if (/[a-z]/.test(jelsz[i])) {
            kicsi = true;
        } else if (/[A-Z]/.test(jelsz[i])) {
            nagy = true;
        } else if (/[0-9]/.test(jelsz[i])) {
            szam = true;
        }else if(/[\.\_]/.test(jelsz[i])){
            spec = true;
        }
        else
        {
            return false;
        }
    }
    return kicsi && nagy && szam && spec;
}

function pwReExit() {
    let pw=document.getElementById("regpw").value;
    let pwre=document.getElementById("regpwre").value;
    if (pw!=pwre) {
        document.getElementById("regpwre").setCustomValidity("A jelszó nem egyezik");
        document.getElementById("regpwre").style.border="1px solid red";
        document.getElementById("info").innerHTML="A két jelszó nem egyezik";
    } else {
        document.getElementById("regpwre").setCustomValidity("");
        document.getElementById("regpwre").style.border="1px solid gray";
        document.getElementById("info").innerHTML="";
    }
}

function BejelentkezesGen()
{
    let kartya = document.getElementById("kartya");
    kartya.innerHTML =" ";
    kartya.innerHTML = `
    <br>
    <h1>Bejelentkezés</h1>
    <br>
    <form id="regForm" class="col-6 col-sm-12">
      <label for="regem">E-mail</label>
      <br>
      <input type="email" class="form-control" id="regem" placeholder="E-mail">
      <br>
      <label for="fnjelsz">Jelszó</label>
      <br>
      <input type="password" class="form-control" id="fnjelsz" placeholder="Jelszó">
      <br>
      <div class="text-center">
      <input type="button" class="btn btn-light col-12" value="Bejelentkezés" onclick="login()"><br>
      <a onclick="RegGen()" id="reg">Nincs még fiókom</a>
      <br>
      <a onclick="BejelentkezesGen()" id="elfjeszo">Elfelejtettem a jelszavam</a>
  </form>
  </div>`;
}

function RegGen()
{
    let kartya = document.getElementById("kartya");
    kartya.innerHTML =" ";
    kartya.innerHTML =`
    <br>
    <h1>Regisztráció</h1>
    <br>
    <form id="regForm" class="col-6 col-sm-12">
    <label for="regfn">Felhasználónév</label>
    <br>
    <input type="text" class="form-control" placeholder="Felhasználónév" id="regFf">
    <label for="regem">E-mail</label>
    <br>
    <input type="email" class="form-control" id="regem" placeholder="E-mail">
    <br>
    <label for="regem">Osztály</label>
    <br>
    <input type="text" class="form-control" id="regem" placeholder="12C">
    <br>
    <label for="fnjelsz">Jelszó</label>
    <br>
    <input type="password" class="form-control" id="fnjelsz" placeholder="Jelszó">
    <br>
    <input type="password" class="form-control" id="fnjelszujra" placeholder="Jelszó újra">
    <br>
    <div class="text-center">
    <input type="button" class="btn btn-light col-12" value="Regisztráció" onclick="regisztracio()">
    <br>
    <a onclick="BejelentkezesGen()" id="bejelentkezes">Van már fiókom</a>
  </div>`;

}
