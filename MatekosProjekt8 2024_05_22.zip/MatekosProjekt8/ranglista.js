var limit = 0;

function RangLista() {
  document.body.innerHTML = "";   
  CreateTable(null, "ranglista");
  var hely = document.getElementById("ranglista");
  hely.innerHTML += `
    <thead>
      <tr>
        <th>Helyezés</th>
        <th>Felhasználónév</th>
        <th>Megoldott feladatok száma</th>
      </tr>
    </thead>
    <tbody id="ranglista-tbody"></tbody>`;
  
  let sql = `SELECT 
    f.id AS felhasznalo_id,
    f.FelhasznaloNev AS felhasznalo_nev,
    COALESCE(COUNT(ff.feladatId), 0) AS megoldott_feladatok_szama,
    COALESCE(MIN(ff.megoldIdo), '9999-12-31') AS legkorabbi_megoldIdo,
    RANK() OVER (
      ORDER BY 
        COALESCE(COUNT(ff.feladatId), 0) DESC, 
        COALESCE(MIN(ff.megoldIdo), '9999-12-31') ASC
    ) AS helyezes,
    CASE 
      WHEN COUNT(ff.feladatId) = 0 THEN 'nincs megoldott feladat'
      ELSE 'van megoldott feladat'
    END AS felhasznalo_tipus
  FROM 
    felhasznalok f
  LEFT JOIN 
    felhaszesfeladkapcs ff ON f.id = ff.felhasznaloId 
  GROUP BY 
    f.id, f.FelhasznaloNev
  ORDER BY 
    helyezes
    LIMIT 15 OFFSET ${limit};
  `;
console.log(sql);
  LekerdezesEredmenye(sql).then((x) => {
    let tbody = document.getElementById("ranglista-tbody");
    x.forEach(element => {
      console.log(element.felhasznalo_id);
      tbody.innerHTML += `
        <tr>
        <td style="${element.felhasznalo_id == sessionStorage.fnid ? 'background-color: green;' : ''}">${element.helyezes}</td>
          <td>${element.felhasznalo_nev}</td>
          <td>${element.megoldott_feladatok_szama}</td>
        </tr>`;
    });
  });
  document.body.innerHTML+=`<nav aria-label="Page navigation example" id="oldalvalto">
  <ul class="pagination justify-content-center">
    <li class="page-item">
      <a class="page-link" id="elozo" onclick="Elozo()">Visszaugrás</a>
    </li>
    <li class="page-item" onclick="SzamClick(this.querySelector('a').id)"><a class="page-link" id="elso">1</a></li>

    <li class="page-item" onclick="SzamClick(this.querySelector('a').id)"><a class="page-link" id="masodik">2</a></li>
    <li class="page-item" onclick="SzamClick(this.querySelector('a').id)" ><a class="page-link" id="harmadik">3</a></li>
    <li class="page-item">
      <a class="page-link" id="kovetkezo" onclick="Kovetkezo()">Előreugrás</a>
    </li>
  </ul>
</nav>`;
}

function CreateTable(hely, id) {
  if (hely == null) {
    document.body.innerHTML = `<table class="table table-dark table-striped" id='${id}'></table>`;
  } else {
    hely.innerHTML += `<table class="table table-dark table-striped" id='${id}'></table>`;
  }
}

function SzamClick3(id) {
  if (id == "elso") {
    fooldaoldalszam = parseInt(document.getElementById("elso").innerHTML);
  } else if (id == "masodik") {
    fooldaoldalszam = parseInt(document.getElementById("masodik").innerHTML);
  } else if (id == "harmadik") {
    fooldaoldalszam = parseInt(document.getElementById("harmadik").innerHTML);
  }
  //limitAlso = (fooldaoldalszam - 1) * 15;
  limit += 15;
  elozolenyomott = id;
  FeladatListaz2();
}

function FeladatListaz3() {
  console.log(`fnid az ez(${sessionStorage.fnid})`);

  let sqlFeladatok = `SELECT IF(f.id IN (
      SELECT f.id 
      FROM feladatok f, felhaszesfeladkapcs ff
      WHERE f.id = ff.feladatId AND ff.felhasznaloid = ${sessionStorage.fnid}), "1", "0") AS megoldott, f.*
    FROM feladatok f
    LIMIT ${limitAlso}, ${limitFelso};`;

  console.log(sqlFeladatok);
  LekerdezesEredmenye(sqlFeladatok).then((valasz) => {
    feladatok = [];
    valasz.forEach((adat) => {
      feladatok.push({
        id: adat.id,
        temakorId: adat.temakorID,
        megoldas: adat.megoldas,
        nehezseg: adat.nehezseg,
        pontszam: adat.pontszam,
        nev: adat.nev,
        feladat: adat.feladat,
        megoldott: adat.megoldott,
      });
    });
    console.log(feladatok, "feladatok: ");
    FeladatokFeltolt2("kereses");
    eredetiSzurt = feladatok;
  });

}

function FeladatokFeltolt3(divId) {
  var hely = document.getElementById(divId);
  hely.innerHTML = "";
  feladatok.forEach((adattag) => {
    let div = document.createElement("div");
    div.id = adattag.id;
    if (adattag.megoldott == 0) {
      div.style.opacity = 1;
    } else {
      div.style.backgroundColor = "rgb(40,40,40,0.5)";
    }
    div.classList.add("feladat");
    div.classList.add("col-12");
    div.classList.add("row");
    let szinResult = Szinez(adattag.nehezseg);
    div.innerHTML = `
    <div id="maindiv${adattag.id}" data-adattag="jobbra" class="sorszam col-3 text-center" style="background-color: ${szinResult.color}" onclick="Hozzaad(this,${adattag.id})">
    <p id="svg${adattag.id}"><svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
    <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
  </svg></p>
</div>
<div class="feladatNev col-5">
    <p>${adattag.nev}</p>
</div>`;
    TemakorBeiir(adattag.temakorId, `${adattag.id}temakorP`);
    hely.appendChild(div);
  });
}