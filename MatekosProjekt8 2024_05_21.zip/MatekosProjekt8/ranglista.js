function RangLista(){
    let sql = `SELECT 
  f.id AS felhasznalo_id,
  f.FelhasznaloNev AS felhasznalo_nev,
  COUNT(ff.feladatId) AS megoldott_feladatok_szama,
  RANK() OVER (ORDER BY COUNT(ff.feladatId) DESC) AS helyezes
FROM 
  felhasznalok f
INNER JOIN 
  felhaszesfeladkapcs ff ON f.id = ff.felhasznaloId 
GROUP BY 
  f.id, f.felhasznaloNev
ORDER BY 
  helyezes;
`;
LekerdezesEredmenye(sql).then((x) =>{
    console.log(x);
})


}