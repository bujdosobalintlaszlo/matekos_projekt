//Szintszureshez valotozok
var OsszesSzur = false;
var kozepSzur = false;
var emeltSzur = false;
var versenySzur = false;
var jelSzur = false;
//------------------
//ebbe gyujtjuk a kiszurt feladatokat es jelenitjuk meg(ez egy tomb)
var szurt =[];
var eredetiSzurt=[];
//--------------

function Szur() {
    console.log(eredetiSzurt,szurt);
    szurt =[];
    if (kozepSzur) {
        szurt = szurt.concat(eredetiSzurt.filter(x => x.nehezseg == "0"));
    } 
    if (emeltSzur) {
        szurt = szurt.concat(eredetiSzurt.filter(x => x.nehezseg == "1"));
    } 
    if (versenySzur) {
        szurt = szurt.concat(eredetiSzurt.filter(x => x.nehezseg == "2"));
    } 
    if (jelSzur) {
        szurt = szurt.concat(eredetiSzurt.filter(x => parseInt(x.nehezseg) >= 3));
    } 
    
    if (!(jelSzur || kozepSzur || emeltSzur || versenySzur)) {
        szurt=eredetiSzurt;
    }
    MegjelenitItems();
}

function KozepSzur() {
    kozepSzur=!kozepSzur;
    Szur();
}

function EmeltSzur() {
    emeltSzur=!emeltSzur;
    Szur();
}


function VersenySzur() {
    versenySzur=!versenySzur;
    Szur();
}

function JelSzur() {
    jelSzur=!jelSzur;
    Szur();
}

function Osszes() {
    szurt=feladatok;
    for (let index = 1; index <= 18; index++) {
        document.getElementById(`${index}`).checked = false;
    }
    MegjelenitItems(feladatok);   
    kozepSzur = false;
    emeltSzur = false;
    versenySzur = false;
    jelSzur = false;
}

function TemakorSzures(id) {
    szurt=[];
    for (let index = 1; index <= 18; index++) {
        // document.getElementById(`${index}`).checked = false;
        if (document.getElementById(`${index}`).checked) {
            szurt = szurt.concat(feladatok.filter(x => x.temakorId == index));
        }
        
    }
    if (szurt.length==0) {
        szurt=feladatok;
    }
    eredetiSzurt=szurt;
    MegjelenitItems(szurt);
}
 function MegjelenitItems(){
        var hely = document.getElementById("jobb");
        hely.innerHTML="";  
        szurt.forEach(adattag=>{
        let div = document.createElement("div");
        div.id = adattag.id;
        div.classList.add("feladat");
        div.classList.add("col-12");
        div.classList.add("row");
        let szinResult = Szinez(adattag.nehezseg);
        div.innerHTML = `
        <div class="sorszam col-3 text-center" style="background-color: ${szinResult.color}">
            <p>${adattag.id}.</p>
        </div>
        <div class="feladatNev col-5">
            <p>${adattag.nev}</p>
        </div>
        <div class="feladatTemakor col-5">
            <p id="${adattag.id}temakorP"></p>
        </div>`;
        TemakorBeiir(adattag.temakorId, `${adattag.id}temakorP`);
        hely.appendChild(div);
        hely.appendChild(document.createElement("br"));
    });
 }